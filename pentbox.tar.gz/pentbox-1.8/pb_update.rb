#!/usr/bin/env ruby

dir = File.dirname(__FILE__)
system("cd #{dir} && svn update")

